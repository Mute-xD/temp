A JavaScript implementation of the websockify WebSocket-to-TCP bridge/proxy.

Copyright (C) 2013 - Joel Martin (github.com/kanaka)

Licensed under LGPL-3.

See http://github.com/kanaka/websockify for more info.
